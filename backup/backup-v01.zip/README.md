# MODULO_VENDAS
Dashboard interativo para visualização comparativa entre prazos previstos e reais de etapas de empreendimentos imobiliários, com gráficos de Gantt e tabelas detalhadas.
